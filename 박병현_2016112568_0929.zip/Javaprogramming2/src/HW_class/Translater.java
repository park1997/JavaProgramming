package HW_class;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.select.Elements;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import org.openqa.selenium.chrome.ChromeOptions;

public class Translater {

    private int interval = 1000;
    private boolean headless = false;


    public Translater() {
    }

    public Translater(boolean headless) {
        this.headless = headless;
    }

    // 한국말을 영어로 번역
    public String translate_KtoE(String text) throws InterruptedException {
        String url_KtoE = "https://papago.naver.com/?sk=ko&tk=en";

        ChromeOptions options = new ChromeOptions();
        if (headless) {
            options.addArguments("--headless");
        }
        options.addArguments("Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/93.0.4577.63 Safari/537.36");
        options.addArguments("disable-gpu");
        options.addArguments("--disable-gpu");
        options.addArguments("lang=ko_KR");
        options.addArguments("window-size=1920x1080"); // 이거 안해주면 headless 때문에 안되고 useragent 넣어줘도 안됨

        ChromeDriver driver = new ChromeDriver();

        // Chrome 열기
        driver.get(url_KtoE);
        Thread.sleep(interval);// 1초 쉬어줌

        // 한국말을 입력할 창을 찾기
        WebElement k_input = driver.findElementByXPath("//*[@id=\"txtSource\"]");
        k_input.sendKeys(text); // 번역할 text 입력
        Thread.sleep(interval); // 1초 쉬어줌

        Document doc = Jsoup.parse(driver.getPageSource());
        Elements e_output_tag = doc.select("div.edit_area___2iv-G div#txtTarget span");

        // 드라이버 종료
        driver.quit();

        return e_output_tag.text();
    }

    // 영어를 한국말로 번역
    public String translate_EtoK(String text) throws InterruptedException {
        String url_EtoK = "https://papago.naver.com/?sk=en&tk=ko&hn=0";

        ChromeOptions options = new ChromeOptions();
        if (headless) {
            options.addArguments("--headless");
        }
        options.addArguments("Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/93.0.4577.63 Safari/537.36");
        options.addArguments("disable-gpu");
        options.addArguments("--disable-gpu");
        options.addArguments("lang=ko_KR");
        options.addArguments("window-size=1920x1080"); // 이거 안해주면 headless 때문에 안되고 useragent 넣어줘도 안됨

        ChromeDriver driver = new ChromeDriver();

        // Chrome 열기
        driver.get(url_EtoK);
        Thread.sleep(interval);// 1초 쉬어줌

        // 한국말을 입력할 창을 찾기
        WebElement e_input = driver.findElementByXPath("//*[@id=\"txtSource\"]");
        e_input.sendKeys(text); // 번역할 text 입력
        Thread.sleep(interval); // 1초 쉬어줌

        Document doc = Jsoup.parse(driver.getPageSource());
        Elements k_output_tag = doc.select("div.edit_area___2iv-G div#txtTarget span");

        // 드라이버 종료
        driver.quit();

        return k_output_tag.text();
    }


}
