package HW_class;

import java.util.Scanner;


public class Main {
    public static void main(String[] args) throws InterruptedException {

        Scanner sc = new Scanner(System.in);
        Option option = new Option(true);

        // Translater 객체 생성
        Translater translater = new Translater();

        System.out.print("번역할 한국어를 입력해 주세요.>");
        String text_k = sc.nextLine();  // 한국어 입력
        System.out.println(translater.translate_KtoE(text_k)); // 한국말이 영어로 번역됨

        System.out.print("번역할 영어를 입력해 주세요.>");
        String text_e = sc.nextLine();  // 영어 입력
        System.out.println(translater.translate_EtoK(text_e)); // 영어가 한국말로 번역됨


    }
}
