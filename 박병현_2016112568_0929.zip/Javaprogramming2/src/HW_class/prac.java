package HW_class;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.select.Elements;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

import java.util.Scanner;
public class prac {
    public static void main(String[] args) throws InterruptedException {

        Scanner sc = new Scanner(System.in);
        System.out.print("번역할 말 입력해 >");
        String text = sc.nextLine();
        int interval = 1000;

        String url_KtoE = "https://papago.naver.com/?sk=ko&tk=en";

        ChromeOptions options = new ChromeOptions();
//        options.addArguments("--headless");
        options.addArguments("Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/93.0.4577.63 Safari/537.36");
        options.addArguments("disable-gpu");
        options.addArguments("--disable-gpu");
        options.addArguments("lang=ko_KR");
        options.addArguments("window-size=1920x1080"); // 이거 안해주면 headless 때문에 안되고 useragent 넣어줘도 안됨

        ChromeDriver driver = new ChromeDriver();

        // Chrome 열기
        driver.get(url_KtoE);
        Thread.sleep(interval);// 1초 쉬어줌

        // 한국말을 입력할 창을 찾기
        WebElement k_input = driver.findElementByXPath("//*[@id=\"txtSource\"]");
        k_input.sendKeys(text); // 번역할 text 입력
        Thread.sleep(interval); // 1초 쉬어줌

        Document doc = Jsoup.parse(driver.getPageSource());
        Elements e_output_tag = doc.select("div.edit_area___2iv-G div#txtTarget span");
        System.out.println(e_output_tag.text());

    }
}
