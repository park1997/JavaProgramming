package HW_class;

public class Option extends Translater {
    boolean headless; // 이거 할건지말건지
    int width;  // 가로길이 정해주기
    int height; // 높이정해 주기
    int interval;

    public Option(boolean headless) {
        super(headless);
        this.headless = headless;
    }


}
